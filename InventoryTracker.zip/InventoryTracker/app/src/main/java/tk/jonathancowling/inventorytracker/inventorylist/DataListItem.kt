package tk.jonathancowling.inventorytracker.inventorylist

class DataListItem(override val id: Int, override var name: String, override var quantity: Int, var isInUse: Boolean):
    ListItem(id, name, quantity)