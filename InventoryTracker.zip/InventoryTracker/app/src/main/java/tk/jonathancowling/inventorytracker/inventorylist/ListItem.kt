package tk.jonathancowling.inventorytracker.inventorylist

open class ListItem(open val id: Int, open var name: String, open var quantity: Int)