package tk.jonathancowling.inventorytracker.inventorylist

import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel

class Model : ViewModel() {
    private val mItems: MutableLiveData<MutableList<DataListItem>> = MutableLiveData()

    init {
        mItems.value = mutableListOf()
    }

    fun addItem(name: String, quantity: Int) {
        val newId = mItems.value!!
            .firstOrNull { !it.isInUse }
            ?.id?.apply { mItems.value!!.removeAt(this) }
            ?: mItems.value!!.size

        mItems.value!!.add(0, DataListItem(newId, name, quantity, true))
    }

    fun removeItem(id: Int) {
        mItems.value!!.let{ list -> list.remove(list.single{ it.id == id })}
    }

    fun changeName(id: Int, newName: String) {
        mItems.value!!.single { it.id == id }.name = newName
    }

    fun changeQuantity(id: Int, newQuantity: Int) {
        mItems.value!!.single { it.id == id }.quantity = newQuantity
    }
}